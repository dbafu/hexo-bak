# coding: utf-8

import os

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

b = os.path.abspath('.')
c = os.path.join(b, 'source')
md_dir = os.path.join(c, '_posts')
# print(md_dir)
os.chdir(md_dir)
# os.system('ls')

md_list = [md for md in os.listdir(md_dir) if os.path.isdir(md_dir)]
md_path_list = [os.path.abspath(path) for path in md_list]
# print(md_list)
# print(md_path_list)

def translate(title_cn):
    url = 'https://translate.google.cn/#zh-CN/en/'
    driver = webdriver.Chrome()
    driver.get(url)
    time.sleep(5)
    input = driver.find_element_by_id('source')
    input.send_keys(title_cn)
    time.sleep(2)

    result = driver.find_element_by_css_selector('span#result_box span')
    text = result.text
    driver.close()
    text = text.replace(' ', '-')
    return text


def mod_md(filepath):
    if 'DS_Store' in filepath:
        return
    l = []
    print(filepath)
    with open(filepath, 'r', encoding='utf8') as f:
        lines = f.readlines()
        i = 0
        line = ''
        ln = 0
        line_num = min(12, len(lines))
        while i < line_num:
            if 'permalink' in lines[i]:
                ln = i
                line = lines[i]
                break
            i += 1
        title_cn = lines[1].replace('title: ', '')
        # 说明有permanlink 且已翻译，不处理
        if len(line) > 13:
            return
        else:
            print('正在翻译 : ', title_cn)
            title_en = translate(title_cn) + '\n'
            print('翻译结果 : ', title_en)
            print(title_en)
            if ln == 0:  # 说明没有permalink
                line = 'permalink: ' + title_en
                lines.insert(2, line)
            else:   # 说明有permalink, 但是没有翻译
                lines[ln] = 'permalink: ' + title_en
        l = lines

    if len(l) > 0:
        with open(filepath, 'w', encoding='utf-8') as f:
            for line in l:
                f.write(line)


for filepath in md_list:
    mod_md(filepath)
