---
title: 写了一个hexo 标题翻译的Python脚本
permalink: Wrote-a-hexo-title-translation-Python-script
date: 2017-12-20 22:13:48
categories:
  - Python
tags:
  - hexo
---

## 前言
hexo 有一个插件叫做hexo-translate-title，可以把中文标题翻译为英文，并作为该文的网址，
我觉得用英文网址会显的有逼格，所以就有了这篇文章。

## 缘由

hexo-translate-title 有时候会不起作用，不知道为什么。
github: <https://github.com/cometlj/hexo-translate-title>

<!--more-->

> hexo-translate-title
> 使用Google翻译，百度翻译和有道翻译将Hexo中的汉字标题转成英文标题
> 安装与使用
> 安装
> npm install hexo-translate-title --save
> 使用
> 配置hexo根项目下的_config.yml
> translate_title:
      translate_way: google    #google | baidu | youdao
      youdao_api_key: XXX
      youdao_keyfrom: XXX
      is_need_proxy: true     #true | false
      proxy_url: http://localhost:8123
> 我没有可以翻墙的代理所以 `is_need_proxy: true`设为 false
> 注意：判断是否需要配置google本地代理，因为我在本地是开启时才能访问google翻译的，如果没有被墙，请将_config.yml 下的is_need_proxy: true改为false。如果设置为true,请设置本地代理地址
> TODO
> google 获取TKK的时候，是参照[这篇文章](http://blog.csdn.net/life169/article/details/52153929) 里面的JS计算方式(谢谢作者！)，但是更换为初次获取http://translate.google.cn/TKK值，参与计算获取tk时会计算出错，原因待查中。
    有道翻译按照官网提供的API，调用时候出现如下报错，故目前可认为不可用，等待查明原因后修改

## 言归正传  上代码

`fanyi_title.py`

```
# coding: utf-8

import os

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

b = os.path.abspath('.')
c = os.path.join(b, 'source')
md_dir = os.path.join(c, '_posts')
# print(md_dir)
os.chdir(md_dir)
# os.system('ls')

md_list = [md for md in os.listdir(md_dir) if os.path.isdir(md_dir)]
md_path_list = [os.path.abspath(path) for path in md_list]
# print(md_list)
# print(md_path_list)

def translate(title_cn):
    url = 'https://translate.google.cn/#zh-CN/en/'
    driver = webdriver.Chrome()
    driver.get(url)
    time.sleep(5)
    input = driver.find_element_by_id('source')
    input.send_keys(title_cn)
    time.sleep(2)

    result = driver.find_element_by_css_selector('span#result_box span')
    text = result.text
    driver.close()
    text = text.replace(' ', '-')
    return text


def mod_md(filepath):
    if 'DS_Store' in filepath:
        return
    l = []
    print(filepath)
    with open(filepath, 'r', encoding='utf8') as f:
        lines = f.readlines()
        i = 0
        line = ''
        ln = 0
        line_num = min(12, len(lines))
        while i < line_num:
            if 'permalink' in lines[i]:
                ln = i
                line = lines[i]
                break
            i += 1
        title_cn = lines[1].replace('title: ', '')
        # 说明有permanlink 且已翻译，不处理
        if len(line) > 13:
            return
        else:
            print('正在翻译 : ', title_cn)
            title_en = translate(title_cn) + '\n'
            print('翻译结果 : ', title_en)
            print(title_en)
            if ln == 0:  # 说明没有permalink
                line = 'permalink: ' + title_en
                lines.insert(2, line)
            else:   # 说明有permalink, 但是没有翻译
                lines[ln] = 'permalink: ' + title_en
        l = lines

    if len(l) > 0:
        with open(filepath, 'w', encoding='utf-8') as f:
            for line in l:
                f.write(line)


for filepath in md_list:
    mod_md(filepath)


```

### 使用方法：

####依赖：
> Python3
Chrome
Chromedriver


1 将fanyi_title.py放在hexo博客根目录下。

2 执行
```sh
hexo n '我的标题'   # 创建markdown文档
python3 fanyi_title.py   # 翻译标题
```
3 继续编辑markdown文档

4 生成静态页面
```sh
hexo g  # 生成网页
```

我js 能力不够，所以走了曲折方式，好在也可以实现目的。


hexo-translate-title 其实就是将title翻译为英文，并在markdown文档里面增加一行`permalink: Wrote-a-hexo-title-translation-Python-script`



## 总结：

我能力提高了再重新写一个不打开网页就可以翻译的版本。

<https://github.com/cometlj/hexo-translate-title/blob/master/lib/util.js>
<http://blog.csdn.net/life169/article/details/52153929>




