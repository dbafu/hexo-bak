---
title: hexo文章中插入图片
tags:
  - hexo
permalink: hexo-insert-images-in-the-article
date: 2017-12-16 23:49:21
---


之前我一直不知道怎么插入图片，现在知道了。
<!--more-->
使用markdown写文章，插入图片的格式为图片名称，这里要说的是链接地址怎么写。
对于hexo，有两种方式：
使用本地路径：在hexo/source目录下新建一个img文件夹，将图片放入该文件夹下，插入图片时链接即为/img/图片名称。

```
![test](/img/001.jpg)
```

![test](/img/001.jpg)
