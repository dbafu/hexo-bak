---
title: resume
layout: resume
date: 2017-07-29 09:18:32
---

## 个人信息

  - 付腾飞/男/1987

  - 手机：18917596316

  - 求职意向：Python爬虫

  - QQ/Wechat: 2899109958

  - 本科/周口师范学院

  - 技术博客：https://dbafu.github.io

  - Github：https://github.com/dbafu

  - Gitee：http://dbafu.oschina.io/

  - 期望薪资：税前月薪10k~15k，特别喜欢的公司可例外

  - 期望城市：北京

## 自我评价
<br>

本人具有下述的能力，期待一份工作。。。。
希望未来的工作可以让可以一展所长，如果不是直接相关我也想尝试一下。。。


具有独立学习能力，踏实能干，热爱技术，若有不足愿意学习。。。

我左手天生无手指，完全不影响操作计算机，不影响正常生活和工作，如果可以接受，请赶快联系我吧！如果不可以接受，请忽略该职位申请， 不浪彼此时间，谢谢~！

<br><br>

## 技能清单

<br>

以下均为我熟练使用的技能
  - 熟练使用 Python，了解多线程，多进程，协程，及分布式;
  - 熟悉 PIL(Pillow)/pytesseract 可以处理简单的简单验证码
  - 熟练使用 Django
  - 熟悉 pyspider/scrapy;
  - 熟练使用正则表达式，XPATH，CSS_SELECTOR，能够从结构化或非结构化数据中获取信息；
  - 数据库方面，MySQL，熟悉SQL，SQLSERVER，MongoDB，Redis;
  - Python：flask, urllib, pyquery, re, selenium, phantomjs,
  - Linux：Bash/Shell Script  在 Win，Linux，Mac 均可以工作;
  - 了解各种Web前端技术，包括XHTML/XML/CSS/JavaScript/AJAX等；
  - 熟练使用Photoshop
  - 英语：英语还行，可以阅读英文;

<br>

## 开源项目和作品
<br>
https://github.com/dbafu/spiders
<br><br>

## 工作经历
<br>
。。。
<br><br>


## 致谢
<br>
感谢您花时间阅读我的简历，期待能有机会和您共事。
<br><br>

## reference

<br><br><br><br>

----------------
2017年10月24日18:10:38
